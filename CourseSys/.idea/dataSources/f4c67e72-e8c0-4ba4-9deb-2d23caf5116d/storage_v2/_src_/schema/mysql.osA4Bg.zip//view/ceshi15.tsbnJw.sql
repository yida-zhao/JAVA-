create view ceshi15 as /* ALGORITHM=UNDEFINED */
select `mysql`.`ceshi1`.`id` AS `id`, `mysql`.`ceshi1`.`id1` AS `id1`, `mysql`.`ceshi1`.`customer` AS `customer`
from `mysql`.`ceshi1`
where (`mysql`.`ceshi1`.`id` = 11);

