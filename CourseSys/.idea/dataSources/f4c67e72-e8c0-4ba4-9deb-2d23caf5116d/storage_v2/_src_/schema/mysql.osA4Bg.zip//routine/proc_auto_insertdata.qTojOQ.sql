create procedure proc_auto_insertdata()
BEGIN
        
        DECLARE init_data INTEGER DEFAULT 1;
       
        WHILE init_data <= 10000 DO 
        
        INSERT INTO ceshi2 VALUES(init_data,'hello');
        
        SET init_data = init_data + 1;
        
        END WHILE; 
END;

