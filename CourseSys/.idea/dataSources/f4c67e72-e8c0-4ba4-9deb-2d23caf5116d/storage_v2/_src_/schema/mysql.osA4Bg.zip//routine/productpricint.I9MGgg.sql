create procedure productpricint()
begin
 
select avg(id) as priceaverage from ceshi1;
 
end;

