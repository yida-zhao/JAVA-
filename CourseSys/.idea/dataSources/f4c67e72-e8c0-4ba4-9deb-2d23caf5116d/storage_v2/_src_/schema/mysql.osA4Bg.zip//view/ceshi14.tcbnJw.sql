create view ceshi14 as /* ALGORITHM=UNDEFINED */
select `mysql`.`ceshi1`.`id` AS `id`, `mysql`.`ceshi1`.`id1` AS `id1`, `mysql`.`ceshi1`.`customer` AS `customer`
from `mysql`.`ceshi1`;

