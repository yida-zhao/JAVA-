create procedure p2()
begin
declare row_id int;
declare row_product varchar(90);
declare getproduct cursor for select id,product from ceshi3;
open getproduct;
fetch getproduct into row_id,row_product;
select row_id,row_product;
close getproduct;
end;

