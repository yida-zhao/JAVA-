create view ceshi9 as /* ALGORITHM=UNDEFINED */
select `mysql`.`ceshi1`.`id` AS `id`
from `mysql`.`ceshi1`;

