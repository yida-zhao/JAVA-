create procedure ceshi20(IN id INTEGER(10))
begin
 
delete from ceshi1 where id = id;
 
end;

